package com.example.admin.augscan;

public class User {
    public String deptname, email,pass;

    public User(){

    }

    public User(String name, String email, String pass) {
        this.deptname = name;
        this.email = email;
        this.pass=pass;
    }
}
